"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle2, Loader2 } from "lucide-react"

export function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="bg-card border border-border p-12 text-center">
        <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto">
          <CheckCircle2 className="h-8 w-8 text-accent" />
        </div>
        <h3 className="mt-6 text-xl font-semibold text-foreground">Thank You for Your Inquiry</h3>
        <p className="mt-3 text-muted-foreground leading-relaxed">
          We have received your request and will review your requirements. Our team will contact you within 24-48
          business hours.
        </p>
        <Button className="mt-8" onClick={() => setIsSubmitted(false)}>
          Submit Another Request
        </Button>
      </div>
    )
  }

  return (
    <div className="bg-card border border-border p-8 lg:p-12">
      <h2 className="text-xl font-semibold text-foreground">Quote Request Form</h2>
      <p className="mt-2 text-muted-foreground">
        Fill out the form below and we'll get back to you with a detailed quote.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="firstName">First Name *</Label>
            <Input id="firstName" name="firstName" required placeholder="Enter your first name" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName">Last Name *</Label>
            <Input id="lastName" name="lastName" required placeholder="Enter your last name" />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input id="email" name="email" type="email" required placeholder="your@email.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input id="phone" name="phone" type="tel" placeholder="+91 XXXXX XXXXX" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="company">Company Name *</Label>
          <Input id="company" name="company" required placeholder="Your company name" />
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="material">Preferred Material</Label>
            <Select name="material">
              <SelectTrigger id="material">
                <SelectValue placeholder="Select material" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ms">Mild Steel (MS)</SelectItem>
                <SelectItem value="ss304">Stainless Steel 304</SelectItem>
                <SelectItem value="ss316">Stainless Steel 316</SelectItem>
                <SelectItem value="unsure">Not Sure / Need Consultation</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="screenType">Screen Type</Label>
            <Select name="screenType">
              <SelectTrigger id="screenType">
                <SelectValue placeholder="Select screen type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high-frequency">High Frequency</SelectItem>
                <SelectItem value="linear">Linear Motion</SelectItem>
                <SelectItem value="circular">Circular Motion</SelectItem>
                <SelectItem value="gyratory">Gyratory</SelectItem>
                <SelectItem value="sizer">Sizer</SelectItem>
                <SelectItem value="other">Other / Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Estimated Quantity</Label>
          <Input id="quantity" name="quantity" placeholder="e.g., 50 units per month" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="specifications">Project Details / Specifications *</Label>
          <Textarea
            id="specifications"
            name="specifications"
            required
            rows={5}
            placeholder="Please describe your requirements. Include details about mesh size, hook type, dimensions, or any other specifications. Mention if you will be providing a drawing or sample."
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="file">Upload Drawing or Specification (Optional)</Label>
          <Input id="file" name="file" type="file" accept=".pdf,.dwg,.dxf,.jpg,.jpeg,.png" className="cursor-pointer" />
          <p className="text-xs text-muted-foreground">Accepted formats: PDF, DWG, DXF, JPG, PNG (Max 10MB)</p>
        </div>

        <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            "Submit Quote Request"
          )}
        </Button>
      </form>
    </div>
  )
}
