import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, ChevronDown } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-[#4a5568] via-[#3d4452] to-[#2d3748]">
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-6 py-32 lg:px-8 text-center">
        <div className="flex flex-col items-center mb-12">
          <div className="relative">
            <Image
              src="/logo.png"
              alt="Mesh Solutions Logo"
              width={180}
              height={180}
              className="mb-8 drop-shadow-2xl"
              priority
            />
          </div>

          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold tracking-[0.2em] text-white uppercase">
            MESH SOLUTIONS
          </h1>

          <div className="w-32 h-px bg-white/30 my-6" />

          <p
            className="text-lg md:text-xl lg:text-2xl font-medium tracking-[0.15em] italic"
            style={{ color: "#7dd3fc" }}
          >
            Precision Redefined
          </p>
        </div>

        <h2 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight text-white/90 mt-16">
          Custom Screen Cloth
          <br />
          <span style={{ color: "#7dd3fc" }}>Engineered to Your Specifications</span>
        </h2>

        <p className="mx-auto mt-6 max-w-2xl text-base md:text-lg text-white/60 leading-relaxed">
          We manufacture quality customized vibrating screen cloth in MS, SS304, and SS316. From your drawing or sample,
          we deliver precision-engineered solutions.
        </p>

        <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            size="lg"
            className="bg-[#7dd3fc] hover:bg-[#7dd3fc]/90 text-[#1e293b] font-semibold tracking-wide px-8"
            asChild
          >
            <Link href="/contact">
              Request a Quote
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 bg-transparent font-medium tracking-wide px-8"
            asChild
          >
            <Link href="/products">Explore Products</Link>
          </Button>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <div className="flex flex-col items-center gap-2 text-white/40">
          <span className="text-xs uppercase tracking-[0.2em]">Scroll</span>
          <ChevronDown className="h-5 w-5 animate-bounce" />
        </div>
      </div>
    </section>
  )
}
