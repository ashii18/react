import Link from "next/link"
import { ArrowRight, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"

const products = [
  {
    name: "Coarse Mesh Screen Cloth",
    description: "Heavy-duty vibrating screen cloth for primary screening applications.",
    image: "/coarse-industrial-metal-mesh-screen-cloth-close-up.jpg",
  },
  {
    name: "Fine Mesh Screen Cloth",
    description: "Precision woven screens for secondary and fine particle separation.",
    image: "/fine-woven-metal-mesh-screen-cloth-industrial.jpg",
  },
  {
    name: "Custom Hook Solutions",
    description: "Any hook type manufactured to your exact specifications and drawings.",
    image: "/metal-screen-cloth-hooks-manufacturing-industrial.jpg",
  },
]

export function ProductsPreviewSection() {
  return (
    <section className="bg-secondary py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
          <div className="max-w-2xl">
            <p className="text-sm font-medium uppercase tracking-widest text-accent">Our Products</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl text-balance">
              Precision Screen Solutions
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              We manufacture coarse and fine mesh vibrating screen cloth with hooks in MS, SS304 or 316 as per customer
              drawing design or sample.
            </p>
          </div>
          <Button variant="outline" asChild className="self-start lg:self-auto bg-transparent">
            <Link href="/products">
              View All Products
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <Link key={product.name} href="/products" className="group relative aspect-[4/3] overflow-hidden bg-muted">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-lg font-semibold text-primary-foreground">{product.name}</h3>
                <p className="mt-2 text-sm text-primary-foreground/70">{product.description}</p>
              </div>
              <div className="absolute top-4 right-4 w-10 h-10 rounded-full bg-card flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Plus className="h-5 w-5 text-foreground" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
