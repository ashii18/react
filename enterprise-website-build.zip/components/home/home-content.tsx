import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { HeroSection } from "@/components/home/hero-section"
import { StatsSection } from "@/components/home/stats-section"
import { ValuePropsSection } from "@/components/home/value-props-section"
import { ProductsPreviewSection } from "@/components/home/products-preview-section"
import { CapabilitiesSection } from "@/components/home/capabilities-section"
import { CTASection } from "@/components/home/cta-section"

export function HomeContent() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <StatsSection />
        <ValuePropsSection />
        <ProductsPreviewSection />
        <CapabilitiesSection />
        <CTASection />
      </main>
      <Footer />
    </>
  )
}
