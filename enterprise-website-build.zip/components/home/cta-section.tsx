import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="relative bg-gradient-to-b from-[#2d3748] to-[#1e293b] py-24 lg:py-32 overflow-hidden">
      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
          backgroundSize: "40px 40px",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-white">Let's Discuss Your Project</h2>
        <p className="mx-auto mt-6 max-w-xl text-white/60 leading-relaxed">
          Send us your drawing or sample. We'll deliver quality screen cloths manufactured to your exact specifications.
        </p>
        <div className="mt-10">
          <Button
            size="lg"
            className="bg-[#7dd3fc] hover:bg-[#7dd3fc]/90 text-[#1e293b] font-semibold tracking-wide px-8"
            asChild
          >
            <Link href="/contact">
              Request a Quote
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
