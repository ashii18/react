const stats = [
  { value: "500+", label: "Units Monthly Capacity" },
  { value: "3", label: "Material Options" },
  { value: "100%", label: "Custom Manufacturing" },
  { value: "ISO", label: "Quality Certified" },
]

export function StatsSection() {
  return (
    <section className="relative bg-gradient-to-r from-[#2d3748] to-[#1e293b] py-20 lg:py-24 overflow-hidden">
      {/* Subtle grid pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)`,
          backgroundSize: "30px 30px",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <div key={stat.label} className="text-center group">
              <p className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight" style={{ color: "#7dd3fc" }}>
                {stat.value}
              </p>
              <p className="mt-3 text-sm text-white/50 uppercase tracking-[0.15em]">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
