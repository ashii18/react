import { Plus } from "lucide-react"

const products = [
  {
    name: "Coarse Mesh Screen Cloth",
    description:
      "Heavy-duty vibrating screen cloth designed for primary screening applications. Ideal for large particle separation in mining, quarrying, and aggregate processing.",
    specs: ["Aperture: 10mm - 100mm", "Wire Diameter: 3mm - 10mm", "Materials: MS, SS304, SS316"],
    image: "/coarse-industrial-metal-mesh-screen-cloth-close-up.jpg",
  },
  {
    name: "Fine Mesh Screen Cloth",
    description:
      "Precision woven screens for secondary and fine particle separation. Perfect for dewatering, sizing, and classification applications.",
    specs: ["Aperture: 0.5mm - 10mm", "Wire Diameter: 0.5mm - 3mm", "Materials: MS, SS304, SS316"],
    image: "/fine-woven-metal-mesh-screen-cloth-industrial.jpg",
  },
  {
    name: "Hook Edge Screens",
    description:
      "Custom hooks manufactured to your exact specifications. Any hook type available as per your drawing or sample requirements.",
    specs: ["Multiple Hook Profiles", "Custom Edge Options", "All Standard Materials"],
    image: "/metal-screen-cloth-hooks-manufacturing-industrial.jpg",
  },
  {
    name: "High Frequency Screens",
    description:
      "Optimized for high frequency vibrating screen applications requiring precise tensioning and durability under continuous operation.",
    specs: ["Enhanced Durability", "Precision Tensioning", "Extended Service Life"],
    image: "/high-frequency-vibrating-screen-mesh-industrial.jpg",
  },
  {
    name: "Linear Motion Screens",
    description:
      "Designed specifically for linear motion screen equipment with proper tensioning characteristics and wear resistance.",
    specs: ["Linear Compatibility", "Optimal Flex Properties", "Consistent Performance"],
    image: "/linear-motion-screen-mesh-cloth-industrial.jpg",
  },
  {
    name: "Gyratory Screen Cloth",
    description:
      "Purpose-built for gyratory and tumbler screens requiring specific mesh characteristics for efficient material separation.",
    specs: ["Gyratory Compatible", "Multi-Plane Motion", "Precision Woven"],
    image: "/gyratory-tumbler-screen-mesh-industrial.jpg",
  },
]

export function ProductsGrid() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <div
              key={product.name}
              className="group bg-card border border-border overflow-hidden hover:border-accent/50 transition-colors"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-muted">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 right-4 w-10 h-10 rounded-full bg-card flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Plus className="h-5 w-5 text-foreground" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-foreground">{product.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{product.description}</p>
                <ul className="mt-4 space-y-1">
                  {product.specs.map((spec) => (
                    <li key={spec} className="text-xs text-muted-foreground">
                      • {spec}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
