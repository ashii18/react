import { CheckCircle2 } from "lucide-react"

const screenTypes = [
  "High Frequency Screens",
  "Linear Motion Screens",
  "Circular Motion Screens",
  "Sizers",
  "Gyratory Screens",
  "Tumbler Screens",
  "Vibrating Feeders",
  "Dewatering Screens",
]

export function ScreenTypesSection() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-2 lg:gap-24 items-center">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">Compatibility</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl text-balance">
              Screen Cloths for Every Application
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              We manufacture screen cloths with hooks for all major screen types. Our products are compatible with
              equipment from leading manufacturers worldwide.
            </p>

            <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {screenTypes.map((type) => (
                <div key={type} className="flex items-center gap-3">
                  <CheckCircle2 className="h-5 w-5 text-accent flex-shrink-0" />
                  <span className="text-foreground">{type}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square overflow-hidden bg-muted">
              <img
                src="/industrial-vibrating-screen-equipment-mining.jpg"
                alt="Vibrating screen equipment"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-accent/10 -z-10" />
          </div>
        </div>
      </div>
    </section>
  )
}
