import { Shield, FileCheck, Gauge, ClipboardCheck, Settings, Search, Workflow, BarChart3 } from "lucide-react"

const qualityServices = [
  {
    icon: Shield,
    name: "Quality Centre",
    description: "Centralized quality management and control ensuring consistent product excellence.",
  },
  {
    icon: Search,
    name: "C&R / Firewall Inspection",
    description: "Comprehensive containment and review inspection protocols for quality assurance.",
  },
  {
    icon: Workflow,
    name: "In Process & Final Quality",
    description: "Rigorous quality checks throughout manufacturing and before final delivery.",
  },
  {
    icon: ClipboardCheck,
    name: "QRE Support",
    description: "Quality Resident Engineering support for customer requirements and specifications.",
  },
  {
    icon: Shield,
    name: "Quality Assurance",
    description: "Complete QA protocols ensuring products meet all specified requirements.",
  },
  {
    icon: FileCheck,
    name: "QMS Development",
    description: "Quality Management System development and implementation services.",
  },
  {
    icon: Settings,
    name: "PPAP Support",
    description: "Production Part Approval Process documentation and support for automotive clients.",
  },
  {
    icon: BarChart3,
    name: "Supplier Audit",
    description: "Comprehensive supplier quality auditing and assessment services.",
  },
  {
    icon: Workflow,
    name: "Production Planning",
    description: "Strategic production planning and control for optimal manufacturing efficiency.",
  },
  {
    icon: Gauge,
    name: "CMM Measurement",
    description: "Coordinate Measuring Machine for precise dimensional analysis and complete reporting.",
  },
]

export function QualityServices() {
  return (
    <section className="bg-secondary py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">Quality Services</p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
            Comprehensive Quality Management
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Our iQualityOne division provides end-to-end quality services ensuring every product meets the highest
            industry standards.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {qualityServices.map((service) => (
            <div
              key={service.name}
              className="bg-card border border-border p-6 hover:border-accent/50 transition-colors"
            >
              <service.icon className="h-8 w-8 text-accent" />
              <h3 className="mt-4 font-semibold text-foreground">{service.name}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
