import { Factory, Users, Ruler, Clock } from "lucide-react"

const capacityStats = [
  {
    icon: Factory,
    value: "500+",
    label: "Units Per Month",
    description: "Manufacturing capacity for customized screen cloth",
  },
  {
    icon: Ruler,
    value: "100%",
    label: "Custom Built",
    description: "Every product manufactured to your specifications",
  },
  {
    icon: Clock,
    value: "Fast",
    label: "Turnaround",
    description: "Efficient production and delivery schedules",
  },
  {
    icon: Users,
    value: "Expert",
    label: "Team",
    description: "Skilled professionals in screen cloth manufacturing",
  },
]

export function ManufacturingCapacity() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-2 lg:gap-24 items-center">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">Manufacturing</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl text-balance">
              Capacity to Deliver at Scale
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              We have the capacity for manufacturing 500 units of customized screen cloth per month. Our facility is
              equipped to handle orders of any size while maintaining consistent quality standards.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              You can provide us drawing or sample, and we will deliver quality screen cloths as per your requirement
              with all fittings.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {capacityStats.map((stat) => (
              <div key={stat.label} className="bg-card border border-border p-6">
                <stat.icon className="h-8 w-8 text-accent" />
                <p className="mt-4 text-2xl font-semibold text-foreground">{stat.value}</p>
                <p className="text-sm font-medium text-foreground">{stat.label}</p>
                <p className="mt-2 text-xs text-muted-foreground">{stat.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
