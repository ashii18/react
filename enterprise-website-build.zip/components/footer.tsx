import Link from "next/link"
import Image from "next/image"
import { Mail, Phone, MapPin } from "lucide-react"

const navigation = {
  main: [
    { name: "Home", href: "/" },
    { name: "Products", href: "/products" },
    { name: "Capabilities", href: "/capabilities" },
    { name: "Contact", href: "/contact" },
  ],
  products: [
    { name: "Vibrating Screen Cloth", href: "/products" },
    { name: "Fine Mesh Screens", href: "/products" },
    { name: "Coarse Mesh Screens", href: "/products" },
    { name: "Custom Solutions", href: "/products" },
  ],
}

export function Footer() {
  return (
    <footer className="bg-[#1e293b] text-white">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Link href="/" className="inline-block">
              <Image src="/logo.png" alt="Mesh Solutions Logo" width={140} height={50} className="h-12 w-auto" />
            </Link>
            <p className="mt-4 text-sm text-white/50 leading-relaxed">
              Precision manufacturing of customized screen cloth solutions for industrial applications worldwide.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em]" style={{ color: "#7dd3fc" }}>
              Navigation
            </h3>
            <ul className="mt-4 space-y-3">
              {navigation.main.map((item) => (
                <li key={item.name}>
                  <Link href={item.href} className="text-sm text-white/50 hover:text-white transition-colors">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em]" style={{ color: "#7dd3fc" }}>
              Products
            </h3>
            <ul className="mt-4 space-y-3">
              {navigation.products.map((item) => (
                <li key={item.name}>
                  <Link href={item.href} className="text-sm text-white/50 hover:text-white transition-colors">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em]" style={{ color: "#7dd3fc" }}>
              Contact
            </h3>
            <ul className="mt-4 space-y-3">
              <li className="flex items-center gap-3 text-sm text-white/50">
                <Mail className="h-4 w-4 flex-shrink-0" style={{ color: "#7dd3fc" }} />
                <span>info@meshsolutions.com</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-white/50">
                <Phone className="h-4 w-4 flex-shrink-0" style={{ color: "#7dd3fc" }} />
                <span>+91 XXXXX XXXXX</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-white/50">
                <MapPin className="h-4 w-4 flex-shrink-0 mt-0.5" style={{ color: "#7dd3fc" }} />
                <span>Manufacturing Facility, Industrial Area</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-8">
          <p className="text-center text-xs text-white/40 tracking-wide">
            &copy; {new Date().getFullYear()} Mesh Solutions. All rights reserved. | Precision Redefined
          </p>
        </div>
      </div>
    </footer>
  )
}
