import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    const { firstName, lastName, email, phone, company, material, screenType, quantity, specifications } = body

    console.log("[v0] Received quote request:", { firstName, lastName, email, company })

    const resendApiKey = process.env.RESEND_API_KEY

    if (!resendApiKey) {
      console.error("[v0] RESEND_API_KEY not configured")
      return NextResponse.json(
        {
          success: false,
          message: "Email service not configured. Please add RESEND_API_KEY to environment variables.",
        },
        { status: 500 },
      )
    }

    const senderEmail = "onboarding@resend.dev"
    const senderName = "Mesh Solutions"
    const companyEmailTo = "ashij180@gmail.com"

    // Email to company
    const companyEmailContent = `
      <h2>New Quote Request Received</h2>
      <p><strong>Client Information:</strong></p>
      <ul>
        <li><strong>Name:</strong> ${firstName} ${lastName}</li>
        <li><strong>Email:</strong> ${email}</li>
        <li><strong>Phone:</strong> ${phone || "Not provided"}</li>
        <li><strong>Company:</strong> ${company}</li>
      </ul>
      <p><strong>Product Requirements:</strong></p>
      <ul>
        <li><strong>Material:</strong> ${material || "Not specified"}</li>
        <li><strong>Screen Type:</strong> ${screenType || "Not specified"}</li>
        <li><strong>Quantity:</strong> ${quantity || "Not specified"}</li>
      </ul>
      <p><strong>Specifications/Details:</strong></p>
      <p>${specifications.replace(/\n/g, "<br>")}</p>
    `

    // Send email to company
    const companyEmailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify({
        from: `${senderName} <${senderEmail}>`,
        to: companyEmailTo,
        reply_to: email,
        subject: `New Quote Request from ${firstName} ${lastName}`,
        html: companyEmailContent,
      }),
    })

    console.log("[v0] Company email response status:", companyEmailResponse.status)

    if (!companyEmailResponse.ok) {
      const errorData = await companyEmailResponse.json()
      console.error("[v0] Company email failed:", errorData)
    }

    // Email to customer
    const customerEmailContent = `
      <h2>Thank You for Your Quote Request</h2>
      <p>Dear ${firstName},</p>
      <p>We have received your quote request for Mesh Solutions screen cloth products. Our team will review your requirements and get back to you within 24-48 business hours.</p>
      <p><strong>Your Request Details:</strong></p>
      <ul>
        <li><strong>Company:</strong> ${company}</li>
        <li><strong>Material:</strong> ${material || "To be determined"}</li>
        <li><strong>Screen Type:</strong> ${screenType || "To be determined"}</li>
      </ul>
      <p>If you have any urgent questions, please feel free to contact us directly at <strong>9766643434</strong> or <strong>sales@meshsolutionsindia.com</strong>.</p>
      <p>Best regards,<br>Mesh Solutions Team</p>
    `

    // Send confirmation email to customer
    const customerEmailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify({
        from: `${senderName} <${senderEmail}>`,
        to: email,
        subject: "Quote Request Confirmation - Mesh Solutions",
        html: customerEmailContent,
      }),
    })

    console.log("[v0] Customer email response status:", customerEmailResponse.status)

    if (!customerEmailResponse.ok) {
      const errorData = await customerEmailResponse.json()
      console.error("[v0] Customer email failed:", errorData)
    }

    return NextResponse.json({ success: true, message: "Quote request submitted successfully" })
  } catch (error) {
    console.error("[v0] Error sending email:", error)
    return NextResponse.json({ success: false, message: "Failed to submit quote request" }, { status: 500 })
  }
}
