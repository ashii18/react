import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductsHero } from "@/components/products/products-hero"
import { ProductsGrid } from "@/components/products/products-grid"
import { MaterialsSection } from "@/components/products/materials-section"
import { ScreenTypesSection } from "@/components/products/screen-types-section"
import { CustomSolutionsSection } from "@/components/products/custom-solutions-section"

export const metadata = {
  title: "Products | Mesh Solutions",
  description:
    "Coarse and fine mesh vibrating screen cloth with hooks in MS, SS304, and SS316. Custom manufactured to your specifications.",
}

export default function ProductsPage() {
  return (
    <>
      <Header />
      <main>
        <ProductsHero />
        <ProductsGrid />
        <MaterialsSection />
        <ScreenTypesSection />
        <CustomSolutionsSection />
      </main>
      <Footer />
    </>
  )
}
