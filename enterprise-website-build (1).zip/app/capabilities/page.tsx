import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CapabilitiesHero } from "@/components/capabilities/capabilities-hero"
import { ManufacturingCapacity } from "@/components/capabilities/manufacturing-capacity"
import { QualityServices } from "@/components/capabilities/quality-services"
import { ProcessSection } from "@/components/capabilities/process-section"
import { CapabilitiesCTA } from "@/components/capabilities/capabilities-cta"

export const metadata = {
  title: "Capabilities & Quality | Mesh Solutions",
  description:
    "iQualityOne quality services including QMS development, PPAP support, CMM measurement, and supplier audit capabilities.",
}

export default function CapabilitiesPage() {
  return (
    <>
      <Header />
      <main>
        <CapabilitiesHero />
        <ManufacturingCapacity />
        <QualityServices />
        <ProcessSection />
        <CapabilitiesCTA />
      </main>
      <Footer />
    </>
  )
}
