"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { IntroAnimation } from "@/components/intro-animation"
import { HomeContent } from "@/components/home/home-content"

export default function HomePage() {
  const [showIntro, setShowIntro] = useState(false)
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    // Check if intro has already been shown this session
    const introShown = sessionStorage.getItem("mesh-intro-shown")
    if (!introShown) {
      setShowIntro(true)
    }
  }, [])

  const handleIntroComplete = () => {
    sessionStorage.setItem("mesh-intro-shown", "true")
    setShowIntro(false)
  }

  // Prevent flash of content before hydration
  if (!isClient) {
    return null
  }

  return (
    <>
      {showIntro && <IntroAnimation onComplete={handleIntroComplete} />}

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: showIntro ? 0 : 1 }}
        transition={{ duration: 0.5, delay: showIntro ? 0.2 : 0 }}
      >
        <HomeContent />
      </motion.div>
    </>
  )
}
