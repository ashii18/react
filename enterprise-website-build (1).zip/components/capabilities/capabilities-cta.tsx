import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CapabilitiesCTA() {
  return (
    <section className="bg-primary py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div>
            <h2 className="text-3xl font-semibold tracking-tight text-primary-foreground sm:text-4xl text-balance">
              Ready to Start Your Project?
            </h2>
            <p className="mt-6 text-primary-foreground/70 leading-relaxed">
              Whether you need a single prototype or large-scale production, our team is ready to deliver quality screen
              cloth solutions that meet your exact specifications.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
                <Link href="/contact">
                  Request a Quote
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 bg-transparent"
                asChild
              >
                <Link href="/products">View Products</Link>
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src="/quality-control-inspection-manufacturing-facility-.jpg"
                alt="Quality inspection and measurement"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-accent/20 -z-10" />
          </div>
        </div>
      </div>
    </section>
  )
}
