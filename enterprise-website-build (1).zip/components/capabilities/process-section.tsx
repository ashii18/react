const processSteps = [
  {
    step: "01",
    title: "Requirement Analysis",
    description:
      "We receive your drawing, sample, or specifications and conduct thorough analysis to understand your exact needs.",
  },
  {
    step: "02",
    title: "Design Confirmation",
    description:
      "Our engineering team confirms all specifications including material, dimensions, hook type, and mesh pattern.",
  },
  {
    step: "03",
    title: "Manufacturing",
    description:
      "Precision manufacturing using quality materials and state-of-the-art equipment in our production facility.",
  },
  {
    step: "04",
    title: "Quality Inspection",
    description: "Rigorous in-process and final quality inspection including CMM measurement and dimensional analysis.",
  },
  {
    step: "05",
    title: "Delivery",
    description: "Careful packaging and timely delivery of finished screen cloths with all fittings and documentation.",
  },
]

export function ProcessSection() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">Our Process</p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl text-balance">
            From Drawing to Delivery
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Our streamlined process ensures quality at every step, from initial requirement analysis to final product
            delivery.
          </p>
        </div>

        <div className="mt-16 relative">
          {/* Connection line */}
          <div className="hidden lg:block absolute top-8 left-0 right-0 h-0.5 bg-border" />

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
            {processSteps.map((item, index) => (
              <div key={item.step} className="relative">
                {/* Step indicator */}
                <div className="relative z-10 w-16 h-16 bg-card border-2 border-accent flex items-center justify-center mx-auto lg:mx-0">
                  <span className="text-lg font-semibold text-accent">{item.step}</span>
                </div>

                <div className="mt-6 text-center lg:text-left">
                  <h3 className="font-semibold text-foreground">{item.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
