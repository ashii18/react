export function CapabilitiesHero() {
  return (
    <section className="relative bg-gradient-to-b from-[#4a5568] to-[#3d4452] pt-32 pb-20 lg:pt-40 lg:pb-28 overflow-hidden">
      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <p className="text-sm font-semibold uppercase tracking-[0.2em]" style={{ color: "#7dd3fc" }}>
          Capabilities & Quality
        </p>
        <h1 className="mt-4 text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white">iQualityOne</h1>
        <p className="mt-6 max-w-2xl text-lg text-white/60 leading-relaxed">
          Comprehensive quality services and manufacturing capabilities. From firewall inspection to complete CMM
          analysis, we deliver precision at every step.
        </p>
      </div>
    </section>
  )
}
