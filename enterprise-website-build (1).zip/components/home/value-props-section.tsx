const valueProps = [
  {
    number: "01",
    title: "Custom Manufacturing",
    description:
      "Provide us your drawing or sample, and we deliver precision screen cloths tailored to your exact specifications.",
  },
  {
    number: "02",
    title: "Quality Materials",
    description:
      "We work with MS, SS304, and SS316 steel grades to ensure durability and performance for your application.",
  },
  {
    number: "03",
    title: "Versatile Solutions",
    description:
      "Screen cloths for high frequency, linear motion, circular motion screens, sizers, and gyratory screens.",
  },
]

export function ValuePropsSection() {
  return (
    <section className="py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em]" style={{ color: "#38bdf8" }}>
            Why Choose Us
          </p>
          <h2 className="mt-4 text-3xl md:text-4xl font-bold tracking-tight text-foreground">
            Engineering Excellence in Every Screen
          </h2>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {valueProps.map((prop) => (
            <div
              key={prop.number}
              className="group relative bg-card border border-border p-8 transition-all duration-300 hover:border-accent/50 hover:shadow-lg hover:shadow-accent/5"
            >
              <span className="text-6xl font-bold opacity-20" style={{ color: "#38bdf8" }}>
                {prop.number}
              </span>
              <h3 className="mt-4 text-xl font-semibold text-foreground tracking-tight">{prop.title}</h3>
              <p className="mt-3 text-muted-foreground leading-relaxed">{prop.description}</p>

              <div
                className="absolute bottom-0 left-0 h-1 w-0 transition-all duration-300 group-hover:w-full"
                style={{ backgroundColor: "#38bdf8" }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
