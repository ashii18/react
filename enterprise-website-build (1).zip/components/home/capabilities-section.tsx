import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, Gauge, ClipboardCheck, Settings } from "lucide-react"

const capabilities = [
  {
    icon: Shield,
    title: "Quality Assurance",
    description: "QMS Development and comprehensive quality management systems.",
  },
  {
    icon: ClipboardCheck,
    title: "PPAP Support",
    description: "Production Part Approval Process for automotive and industrial clients.",
  },
  {
    icon: Gauge,
    title: "CMM Measurement",
    description: "Coordinate Measuring Machine for precise dimensional analysis.",
  },
  {
    icon: Settings,
    title: "Supplier Audit",
    description: "Complete supplier quality auditing and certification support.",
  },
]

export function CapabilitiesSection() {
  return (
    <section className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-2 lg:gap-24 items-center">
          {/* Image */}
          <div className="relative">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src="/quality-control-inspection-manufacturing-facility-.jpg"
                alt="Quality control and inspection"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-accent/10 -z-10" />
          </div>

          {/* Content */}
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">iQualityOne</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl text-balance">
              Unmatched Precision & Quality Standards
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              Our Quality Centre provides comprehensive inspection, quality management, and certification support. From
              firewall inspection to complete CMM analysis.
            </p>

            <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {capabilities.map((capability) => (
                <div key={capability.title} className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-secondary flex items-center justify-center">
                    <capability.icon className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-medium text-foreground">{capability.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{capability.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10">
              <Button asChild>
                <Link href="/capabilities">
                  Learn More
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
