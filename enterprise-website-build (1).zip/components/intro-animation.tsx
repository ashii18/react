"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

export function IntroAnimation({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<"logo" | "title" | "tagline" | "exit">("logo")

  useEffect(() => {
    const titleTimer = setTimeout(() => {
      setPhase("title")
    }, 600)

    const taglineTimer = setTimeout(() => {
      setPhase("tagline")
    }, 1400)

    const exitTimer = setTimeout(() => {
      setPhase("exit")
    }, 2800)

    const completeTimer = setTimeout(() => {
      onComplete()
    }, 3600)

    return () => {
      clearTimeout(titleTimer)
      clearTimeout(taglineTimer)
      clearTimeout(exitTimer)
      clearTimeout(completeTimer)
    }
  }, [onComplete])

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center"
      style={{ backgroundColor: "#4a5568" }}
      initial={{ opacity: 1 }}
      animate={phase === "exit" ? { opacity: 0, scale: 0.98 } : { opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={phase === "exit" ? { opacity: 0, y: -20 } : { opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="mb-8"
      >
        <Image src="/logo.png" alt="Mesh Solutions" width={200} height={200} className="w-32 h-auto md:w-48" priority />
      </motion.div>

      <AnimatePresence>
        {(phase === "title" || phase === "tagline" || phase === "exit") && (
          <motion.h1
            className="text-3xl md:text-5xl lg:text-6xl font-bold tracking-[0.2em] text-white uppercase"
            initial={{ opacity: 0, y: 20 }}
            animate={phase === "exit" ? { opacity: 0, y: -20 } : { opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          >
            MESH SOLUTIONS
          </motion.h1>
        )}
      </AnimatePresence>

      <motion.div
        className="mt-6 h-px bg-white/40"
        initial={{ width: 0 }}
        animate={phase === "exit" ? { width: 0, opacity: 0 } : { width: 160 }}
        transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
      />

      <AnimatePresence>
        {(phase === "tagline" || phase === "exit") && (
          <motion.p
            className="mt-6 text-lg md:text-xl lg:text-2xl font-medium italic tracking-[0.15em]"
            style={{ color: "#7dd3fc" }}
            initial={{ opacity: 0, y: 10 }}
            animate={phase === "exit" ? { opacity: 0, y: -10 } : { opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            Precision Redefined
          </motion.p>
        )}
      </AnimatePresence>
    </motion.div>
  )
}
