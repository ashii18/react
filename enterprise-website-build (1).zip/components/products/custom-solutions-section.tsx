import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CustomSolutionsSection() {
  return (
    <section className="bg-primary py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">Custom Manufacturing</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-primary-foreground sm:text-4xl text-balance">
              Hooks Can Be Any Type As Per Your Spec
            </h2>
            <p className="mt-6 text-primary-foreground/70 leading-relaxed">
              We specialize in manufacturing customized screen cloth to your exact requirements. Provide us your drawing
              or sample, and we will deliver quality screen cloths with all fittings as per your specification.
            </p>

            <ul className="mt-8 space-y-4">
              <li className="flex gap-4">
                <span className="text-accent font-semibold">01</span>
                <span className="text-primary-foreground/70">Send us your drawing or physical sample</span>
              </li>
              <li className="flex gap-4">
                <span className="text-accent font-semibold">02</span>
                <span className="text-primary-foreground/70">We analyze and confirm specifications</span>
              </li>
              <li className="flex gap-4">
                <span className="text-accent font-semibold">03</span>
                <span className="text-primary-foreground/70">Manufacturing to your exact requirements</span>
              </li>
              <li className="flex gap-4">
                <span className="text-accent font-semibold">04</span>
                <span className="text-primary-foreground/70">Quality inspection and delivery</span>
              </li>
            </ul>

            <div className="mt-10">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
                <Link href="/contact">
                  Start Your Custom Order
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="aspect-[3/4] overflow-hidden bg-primary-foreground/10">
                <img
                  src="/metal-mesh-screen-cloth-custom-hooks-close-up.jpg"
                  alt="Custom hook detail"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="aspect-square overflow-hidden bg-primary-foreground/10">
                <img
                  src="/precision-manufacturing-equipment-metal.jpg"
                  alt="Manufacturing equipment"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="space-y-4 mt-8">
              <div className="aspect-square overflow-hidden bg-primary-foreground/10">
                <img
                  src="/technical-drawing-blueprint-screen-mesh.jpg"
                  alt="Technical drawing"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="aspect-[3/4] overflow-hidden bg-primary-foreground/10">
                <img
                  src="/finished-screen-cloth-product-stack-industrial.jpg"
                  alt="Finished products"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
