const materials = [
  {
    name: "Mild Steel (MS)",
    description:
      "Cost-effective solution for general-purpose screening applications where corrosion resistance is not critical.",
    properties: ["High Strength", "Economical", "Easy to Process"],
  },
  {
    name: "Stainless Steel 304",
    description: "Excellent corrosion resistance for food processing, chemical, and pharmaceutical applications.",
    properties: ["Corrosion Resistant", "Food Grade", "Durable"],
  },
  {
    name: "Stainless Steel 316",
    description:
      "Superior corrosion resistance for harsh environments, marine applications, and aggressive chemical exposure.",
    properties: ["Marine Grade", "Chemical Resistant", "Premium Quality"],
  },
]

export function MaterialsSection() {
  return (
    <section className="bg-secondary py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">Materials</p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
            Quality Material Options
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            We work with three primary material grades to meet your specific application requirements and budget.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
          {materials.map((material) => (
            <div key={material.name} className="bg-card border border-border p-8">
              <h3 className="text-xl font-semibold text-foreground">{material.name}</h3>
              <p className="mt-4 text-muted-foreground leading-relaxed">{material.description}</p>
              <div className="mt-6 flex flex-wrap gap-2">
                {material.properties.map((property) => (
                  <span
                    key={property}
                    className="inline-block px-3 py-1 text-xs font-medium bg-secondary text-secondary-foreground"
                  >
                    {property}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
