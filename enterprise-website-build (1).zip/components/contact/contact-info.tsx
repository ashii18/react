import { Mail, Phone, MapPin, Clock } from "lucide-react"

const contactDetails = [
  {
    icon: Mail,
    label: "Email",
    value: "sales@meshsolutionsindia.com",
    href: "mailto:sales@meshsolutionsindia.com",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+91 9766643434",
    href: "tel:+919766643434",
  },
  {
    icon: MapPin,
    label: "Address",
    value: "Gut No 1228, Near IBM College, Sonawane Vasti Road, Chikhali, Pune - 411062",
    href: null,
  },
  {
    icon: Clock,
    label: "Business Hours",
    value: "Mon - Sat: 9:00 AM - 6:00 PM",
    href: null,
  },
]

export function ContactInfo() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-foreground">Get in Touch</h2>
        <p className="mt-2 text-muted-foreground leading-relaxed">
          Have questions? Our team is ready to help you find the right screen cloth solution for your application.
        </p>
      </div>

      <div className="space-y-6">
        {contactDetails.map((item) => (
          <div key={item.label} className="flex gap-4">
            <div className="flex-shrink-0 w-10 h-10 bg-secondary flex items-center justify-center">
              <item.icon className="h-5 w-5 text-accent" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{item.label}</p>
              {item.href ? (
                <a href={item.href} className="text-sm text-muted-foreground hover:text-accent transition-colors">
                  {item.value}
                </a>
              ) : (
                <p className="text-sm text-muted-foreground">{item.value}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-secondary p-6">
        <h3 className="font-semibold text-foreground">How We Work</h3>
        <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
          <li className="flex gap-2">
            <span className="text-accent font-medium">1.</span>
            Send us your drawing or sample
          </li>
          <li className="flex gap-2">
            <span className="text-accent font-medium">2.</span>
            We analyze and confirm specifications
          </li>
          <li className="flex gap-2">
            <span className="text-accent font-medium">3.</span>
            Receive a detailed quote within 48 hours
          </li>
          <li className="flex gap-2">
            <span className="text-accent font-medium">4.</span>
            Approve and start manufacturing
          </li>
        </ul>
      </div>

      <div className="bg-card border border-border p-6">
        <p className="text-sm font-medium text-foreground">Prefer to speak directly?</p>
        <p className="mt-2 text-sm text-muted-foreground">
          Call us during business hours for immediate assistance with your inquiry.
        </p>
      </div>
    </div>
  )
}
