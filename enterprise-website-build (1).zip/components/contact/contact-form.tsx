"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle2, Loader2, AlertCircle } from "lucide-react"

export function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    material: "",
    screenType: "",
    quantity: "",
    specifications: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      const response = await fetch("/api/send-quote", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        setIsSubmitted(true)
        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          phone: "",
          company: "",
          material: "",
          screenType: "",
          quantity: "",
          specifications: "",
        })
      } else {
        setError(data.message || "Failed to submit form. Please try again.")
      }
    } catch (err) {
      setError("An error occurred. Please try again later.")
      console.error("Form submission error:", err)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isSubmitted) {
    return (
      <div className="bg-card border border-border p-12 text-center">
        <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto">
          <CheckCircle2 className="h-8 w-8 text-accent" />
        </div>
        <h3 className="mt-6 text-xl font-semibold text-foreground">Thank You for Your Inquiry</h3>
        <p className="mt-3 text-muted-foreground leading-relaxed">
          We have received your request and sent a confirmation email to <strong>{formData.email}</strong>. Our team
          will review your requirements and contact you within 24-48 business hours.
        </p>
        <Button className="mt-8" onClick={() => setIsSubmitted(false)}>
          Submit Another Request
        </Button>
      </div>
    )
  }

  return (
    <div className="bg-card border border-border p-8 lg:p-12">
      <h2 className="text-xl font-semibold text-foreground">Quote Request Form</h2>
      <p className="mt-2 text-muted-foreground">
        Fill out the form below and we'll get back to you with a detailed quote.
      </p>

      {error && (
        <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
          <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="firstName">First Name *</Label>
            <Input
              id="firstName"
              name="firstName"
              required
              placeholder="Enter your first name"
              value={formData.firstName}
              onChange={handleChange}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName">Last Name *</Label>
            <Input
              id="lastName"
              name="lastName"
              required
              placeholder="Enter your last name"
              value={formData.lastName}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              name="email"
              type="email"
              required
              placeholder="your@email.com"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              placeholder="+91 XXXXX XXXXX"
              value={formData.phone}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="company">Company Name *</Label>
          <Input
            id="company"
            name="company"
            required
            placeholder="Your company name"
            value={formData.company}
            onChange={handleChange}
          />
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="material">Preferred Material</Label>
            <Select value={formData.material} onValueChange={(value) => handleSelectChange("material", value)}>
              <SelectTrigger id="material">
                <SelectValue placeholder="Select material" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ms">Mild Steel (MS)</SelectItem>
                <SelectItem value="ss304">Stainless Steel 304</SelectItem>
                <SelectItem value="ss316">Stainless Steel 316</SelectItem>
                <SelectItem value="unsure">Not Sure / Need Consultation</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="screenType">Screen Type</Label>
            <Select value={formData.screenType} onValueChange={(value) => handleSelectChange("screenType", value)}>
              <SelectTrigger id="screenType">
                <SelectValue placeholder="Select screen type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high-frequency">High Frequency</SelectItem>
                <SelectItem value="linear">Linear Motion</SelectItem>
                <SelectItem value="circular">Circular Motion</SelectItem>
                <SelectItem value="gyratory">Gyratory</SelectItem>
                <SelectItem value="sizer">Sizer</SelectItem>
                <SelectItem value="other">Other / Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="quantity">Estimated Quantity</Label>
          <Input
            id="quantity"
            name="quantity"
            placeholder="e.g., 50 units per month"
            value={formData.quantity}
            onChange={handleChange}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="specifications">Project Details / Specifications *</Label>
          <Textarea
            id="specifications"
            name="specifications"
            required
            rows={5}
            placeholder="Please describe your requirements. Include details about mesh size, hook type, dimensions, or any other specifications. Mention if you will be providing a drawing or sample."
            value={formData.specifications}
            onChange={handleChange}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="file">Upload Drawing or Specification (Optional)</Label>
          <Input id="file" name="file" type="file" accept=".pdf,.dwg,.dxf,.jpg,.jpeg,.png" className="cursor-pointer" />
          <p className="text-xs text-muted-foreground">Accepted formats: PDF, DWG, DXF, JPG, PNG (Max 10MB)</p>
        </div>

        <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            "Submit Quote Request"
          )}
        </Button>
      </form>
    </div>
  )
}
